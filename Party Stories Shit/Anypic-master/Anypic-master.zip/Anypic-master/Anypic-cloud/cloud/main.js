require('cloud/installation.js');
require('cloud/activity.js');
require('cloud/photo.js');
